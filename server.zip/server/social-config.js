

/**
ServiceConfiguration.configurations.remove({
    service: 'facebook'
});

ServiceConfiguration.configurations.insert({
    service: 'facebook',
    appId: '423982024658565',
    secret: '6c8480222744b3e6c474cb7cc478611a'
});
*/
